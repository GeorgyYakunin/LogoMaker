package com.logo3d.logomaker;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.logo3d.logomaker.utilities.Constants;
import com.logo3d.logomaker.utilities.MyCards;
import com.logo3d.logomaker.utilities.Utility;

public class MainActivity extends AppCompatActivity implements OnClickListener {
   
    ImageView create;
    ImageView library;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        
        setRequestedOrientation(1);
        
        this.create = (ImageView) findViewById(R.id.create);
        this.library = (ImageView) findViewById(R.id.library);
        this.create.setOnClickListener(this);
        this.library.setOnClickListener(this);
        loadPermissions();


    }

    public void loadPermissions() {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        if (ContextCompat.checkSelfPermission(this, str) != 0) {
            new Utility();
            Utility.checkPermissionContects(this, str);
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            new Utility();
            Utility.checkPermissionContects(this, str);
        }
    }

    public void onClick(View view) {
        if (view.equals(this.create)) {
            startActivity(new Intent(this, CreateLogo.class));
        } else if (view.equals(this.library)) {
            try {
                startActivity(new Intent(this, MyCards.class));
            } catch (Exception unused) {
                Toast.makeText(this, "Sorry! No Item Saved Yet", 0).show();
            }
        }
    }
}
