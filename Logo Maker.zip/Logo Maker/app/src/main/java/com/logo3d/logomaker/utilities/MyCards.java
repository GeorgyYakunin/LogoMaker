package com.logo3d.logomaker.utilities;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.Toast;

import com.logo3d.logomaker.R;

import java.io.File;

public class MyCards extends Activity implements OnItemClickListener {
    File[] totalFiles;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.logolayout);
        GridView gridView = (GridView) findViewById(R.id.gridviewLogo);
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
            sb.append(File.separator);
            sb.append(Constants.D_NAME);
            this.totalFiles = new File(sb.toString()).listFiles();
        } catch (Exception unused) {
            Toast.makeText(this, "No item found", 1).show();
        }
        File[] fileArr = this.totalFiles;
        if (fileArr != null) {
            gridView.setAdapter(new GridViewAdapter((Context) this, fileArr));
            gridView.setOnItemClickListener(this);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        Intent intent = new Intent(this, MyCardsSlider.class);
        intent.putExtra(Constants.SELECTED_ITEM, i);
        startActivity(intent);
    }
}
