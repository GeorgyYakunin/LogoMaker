package com.logo3d.logomaker.utilities;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;

import com.logo3d.logomaker.R;

import java.io.File;

public class MyCardsSlider extends Activity implements OnClickListener {
    File[] file;
    ViewPager pager;


    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.slider_layout);
        
        this.pager = (ViewPager) findViewById(R.id.viewPager);
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append(File.separator);
        sb.append(Constants.D_NAME);
        this.file = new File(sb.toString()).listFiles();
        this.pager.setAdapter(new SliderPagerAdapter(this, this.file));
        this.pager.setCurrentItem(getIntent().getIntExtra(Constants.SELECTED_ITEM, 0));
        findViewById(R.id.share).setOnClickListener(this);

    }


    public void onBackPressed() {
        super.onBackPressed();
    }

    public void shareITems() {
        int currentItem = this.pager.getCurrentItem();
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", "My Logo");
        intent.putExtra("android.intent.extra.TEXT", "Logo Maker");
        intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(this.file[currentItem]));
        intent.setType("image/png");
        intent.addFlags(1);
        startActivity(Intent.createChooser(intent, "send"));
    }

    public void onClick(View view) {
        shareITems();
    }
}
