package com.poster.postmaker;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;
import com.poster.postmaker.utitlities.Utility;
import com.poster.postmaker.workspace.MyCards;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    TextView createLogo;
    TextView myLogos;
    TextView rateApp;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);

        setRequestedOrientation(1);
        this.createLogo = (TextView) findViewById(R.id.create_logo);
        this.myLogos = (TextView) findViewById(R.id.my_logo);
        this.rateApp = (TextView) findViewById(R.id.rateapp);
        this.createLogo.setOnClickListener(this);
        this.myLogos.setOnClickListener(this);
        this.rateApp.setOnClickListener(this);
        loadPermissions();


    }

    public void loadPermissions() {
        String str = "android.permission.WRITE_EXTERNAL_STORAGE";
        if (ContextCompat.checkSelfPermission(this, str) != 0) {
            new Utility();
            Utility.checkPermissionContects(this, str);
        }
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") != 0) {
            new Utility();
            Utility.checkPermissionContects(this, str);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
    }

    public void onClick(View view) {
        if (view.equals(this.createLogo)) {
            startActivity(new Intent(this, CreateLogo.class));
        } else if (view.equals(this.myLogos)) {
            startActivity(new Intent(this, MyCards.class));
        } else if (view.equals(this.rateApp)) {
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse("https://play.google.com/store/apps/developer?id=RaviansSolutions.Inc"));
            startActivity(intent);
        }
    }
}
