package com.poster.postmaker.logosloading;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import com.poster.postmaker.CreateLogo;
import com.poster.postmaker.R;
import com.poster.postmaker.StaticValues;
import com.xiaopo.flying.sticker.DrawableSticker;

public class ItemsHolder extends ViewHolder implements OnClickListener {
    Context context;
    ImageView img2;

    public ItemsHolder(View view, Context context2) {
        super(view);
        this.img2 = (ImageView) view.findViewById(R.id.itemadded);
        this.img2.setOnClickListener(this);
        this.context = context2;
    }

    public void onClick(View view) {
        if (!view.equals(this.img2)) {
            return;
        }
        if (StaticValues.f79i == 1) {
            CreateLogo.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(this.context, StaticValues.logos[getAdapterPosition()])));
            CreateLogo.stickerView.invalidate();
            CreateLogo.logorecylerview.setVisibility(8);
        } else if (StaticValues.f79i == 2) {
            CreateLogo.stickerView.addSticker(new DrawableSticker(ContextCompat.getDrawable(this.context, StaticValues.shapes[getAdapterPosition()])));
            CreateLogo.stickerView.invalidate();
            CreateLogo.logorecylerview.setVisibility(8);
        }
    }
}
