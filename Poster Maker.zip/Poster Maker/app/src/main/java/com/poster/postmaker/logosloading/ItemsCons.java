package com.poster.postmaker.logosloading;

public class ItemsCons {
    private int img2;

    public ItemsCons(int i) {
        this.img2 = i;
    }

    public int getImg2() {
        return this.img2;
    }

    public void setImg2(int i) {
        this.img2 = i;
    }
}
