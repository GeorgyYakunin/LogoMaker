package com.poster.postmaker.workspace;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.poster.postmaker.R;
import com.poster.postmaker.StaticValues;
import java.io.File;

public class MyCardsSlider extends Activity implements OnClickListener {
    ImageView chatmaster;
    ImageView facebook;
    File[] file;
    ImageView googlplus;
    ImageView instagram;
    ImageView linkin;
    ViewPager pager;
    ImageView pinterst;
    ImageView snapchat;
    ImageView twitter;


    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.slider_layout);
        this.pager = (ViewPager) findViewById(R.id.viewPager);
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append(File.separator);
        sb.append(StaticValues.D_NAME);
        this.file = new File(sb.toString()).listFiles();
        this.pager.setAdapter(new SliderPagerAdapter(this, this.file));
        this.pager.setCurrentItem(getIntent().getIntExtra("EXTRA_ITEM", 0));

        initliazeSharingItems();
    }


    public void onBackPressed() {
        super.onBackPressed();
    }

    public void initliazeSharingItems() {
        this.facebook = (ImageView) findViewById(R.id.facebook);
        this.facebook.setOnClickListener(this);
        this.instagram = (ImageView) findViewById(R.id.instagram);
        this.instagram.setOnClickListener(this);
        this.twitter = (ImageView) findViewById(R.id.twitter);
        this.twitter.setOnClickListener(this);
        this.snapchat = (ImageView) findViewById(R.id.snapchat);
        this.snapchat.setOnClickListener(this);
        this.googlplus = (ImageView) findViewById(R.id.googleplus);
        this.googlplus.setOnClickListener(this);
        this.chatmaster = (ImageView) findViewById(R.id.chatmaster);
        this.chatmaster.setOnClickListener(this);
        this.pinterst = (ImageView) findViewById(R.id.pinterst);
        this.pinterst.setOnClickListener(this);
        this.linkin = (ImageView) findViewById(R.id.linkedin);
        this.linkin.setOnClickListener(this);
    }

    public void shareITems() {
        int currentItem = this.pager.getCurrentItem();
        Intent intent = new Intent();
        intent.setAction("android.intent.action.SEND");
        intent.putExtra("android.intent.extra.SUBJECT", "My Logo");
        intent.putExtra("android.intent.extra.TEXT", "LAS Logo Maker");
        intent.putExtra("android.intent.extra.STREAM", Uri.fromFile(this.file[currentItem]));
        intent.setType("image/png");
        intent.addFlags(1);
        startActivity(Intent.createChooser(intent, "send"));
    }

    public void onClick(View view) {
        if (view.equals(this.facebook)) {
            shareITems();
        } else if (view.equals(this.instagram)) {
            shareITems();
        } else if (view.equals(this.twitter)) {
            shareITems();
        } else if (view.equals(this.snapchat)) {
            shareITems();
        } else if (view.equals(this.googlplus)) {
            shareITems();
        } else if (view.equals(this.chatmaster)) {
            shareITems();
        } else if (view.equals(this.pinterst)) {
            shareITems();
        } else if (view.equals(this.linkin)) {
            shareITems();
        }
    }
}
