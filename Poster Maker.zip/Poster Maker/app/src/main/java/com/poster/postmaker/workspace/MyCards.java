package com.poster.postmaker.workspace;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.Toast;

import com.poster.postmaker.R;
import com.poster.postmaker.StaticValues;
import java.io.File;

public class MyCards extends Activity implements OnItemClickListener {

    File[] totalFiles;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.logolayout);

        GridView gridView = (GridView) findViewById(R.id.gridviewLogo);
        StringBuilder sb = new StringBuilder();
        sb.append(Environment.getExternalStorageDirectory().getAbsolutePath());
        sb.append(File.separator);
        sb.append(StaticValues.D_NAME);
        this.totalFiles = new File(sb.toString()).listFiles();
        File[] fileArr = this.totalFiles;
        if (fileArr != null) {
            gridView.setAdapter(new GridViewAdapter((Context) this, fileArr));
            gridView.setOnItemClickListener(this);
            return;
        }
        Toast.makeText(this, "Sorry No Saved item found", 1).show();
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        Intent intent = new Intent(this, MyCardsSlider.class);
        intent.putExtra("EXTRA_ITEM", i);
        startActivity(intent);
    }
}
